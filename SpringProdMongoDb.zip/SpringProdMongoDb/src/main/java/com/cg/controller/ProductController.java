package com.cg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Product;
import com.cg.dao.ProductDao;

@RestController
@RequestMapping("/proddemo")
public class ProductController {
     @Autowired 
     ProductDao proDao;
	@RequestMapping(value="/create",consumes=MediaType.APPLICATION_JSON_VALUE)
	public  String createProd(@RequestBody Product prod)
	{
		proDao.save(prod);
		return ("Data Inserted In the MongoDb");
		
	}
	@GetMapping(value="/fetchAllProd",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Product> fetchAllProd()
	
	{ return proDao.findAll();	}
	
	@DeleteMapping(value="/deleteProduct/{pid}",produces=MediaType.APPLICATION_JSON_VALUE)
	public String deleteProductById(@PathVariable("pid") String prodId)
	{
		proDao.deleteById(prodId);
		return("Data is Deleted");
	}
	@PutMapping(value="/updateProd/{pid}",produces=MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateProductById(@RequestBody Product prod,@PathVariable("pid") String prodId)
	{
		prod.setId(prodId);
		proDao.save(prod);
		
		return "Updated";
	}
	@GetMapping(value="/Search/{pid}",produces=MediaType.APPLICATION_JSON_VALUE)
	public Optional<Product> serach(@PathVariable("pid") String prodId)
	{
		return proDao.findById(prodId);
	}
}


