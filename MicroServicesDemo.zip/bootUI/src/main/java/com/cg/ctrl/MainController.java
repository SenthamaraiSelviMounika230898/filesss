package com.cg.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.dto.Student;

@RestController
public class MainController {
	
	@Autowired
	RestTemplate rest;
	
	@GetMapping(value="/AllStudents")
	public Student[] getStudents() {		
		Student stud[] = rest.getForObject("http://boot-app/getStudents", Student[].class);				
		return stud;
	}
	
	@GetMapping(value="/AllStudents/{id}")
	public Student getStudentById(@PathVariable("id") int id) {		
		Student stud = rest.getForObject("http://boot-app/getStudentById/"+id, Student.class);				
		return stud;
	}
	
	@PostMapping(value="/enterStudent")
	public Student enterStudents(@RequestBody Student stud) {
		Student student = rest.postForObject("http://boot-app/createStudent", stud, Student.class);
		return student;
	} 
	
	@PutMapping(value="/update/{id}")
	public String update(@PathVariable int id, @RequestBody Student stud) {
		rest.put("http://boot-app/updateStudentData/"+id,stud);
		return "Data Updated successfully from ui";
	}
	
	@DeleteMapping(value="/delete/{id}")
	public String delete(@PathVariable int id) {
		rest.delete("http://boot-app/deleteById/"+id);
		return "Data deleted successfully from ui!";
	}
}
