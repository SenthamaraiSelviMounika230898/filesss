package com.cg.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dao.StudentDao;
import com.cg.dto.Student;

@RestController
public class StudentController {
	
	@Autowired
	StudentDao studDao;
	
	@GetMapping(value="/getStudents")
	public List<Student> getStudents(){
		List<Student> list = studDao.findAll();
		return list;
	}
	
	@GetMapping(value="/getStudentById/{id}")
	public Student getById(@PathVariable("id") int id) {
		Student stud = studDao.findById(id).get();
		return stud;
		
	}
	
	@PostMapping(value="/createStudent", consumes=MediaType.APPLICATION_JSON_VALUE)
	public Student createStudent(@RequestBody Student stud)
	{
		studDao.save(stud);
		return stud;
	}
	
	//deleteById?id=1
	@DeleteMapping(value="/deleteById/{id}")
	public void deleteById(@PathVariable(value="id") int id) {
		studDao.deleteById(id);
		
	}
	
	@PutMapping(value="/updateStudentData/{id}", consumes=MediaType.APPLICATION_JSON_VALUE)
	public void updateStudentById(@PathVariable("id") int id, @RequestBody Student stud) {
		stud.setId(id);
		studDao.save(stud);
		
	}
	
	

}
