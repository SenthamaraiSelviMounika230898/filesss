package com.cg.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.cg.dto.Student;

@Repository
public interface StudentDao extends MongoRepository<Student, Integer> {

}
